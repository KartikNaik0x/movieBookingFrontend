package com.kartik.authentication.service;

/**
 * @author {2095949}
 * @Date {03-12-2023}
 */
public interface LoginService {
}
