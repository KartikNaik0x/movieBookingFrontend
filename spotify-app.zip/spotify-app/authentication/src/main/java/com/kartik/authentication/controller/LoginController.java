package com.kartik.authentication.controller;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author {2095949}
 * @Date {02-12-2023}
 */

@RestController
public class LoginController {

}
