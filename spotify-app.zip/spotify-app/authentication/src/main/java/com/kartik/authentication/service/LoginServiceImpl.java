package com.kartik.authentication.service;

import org.springframework.stereotype.Service;

/**
 * @author {2095949}
 * @Date {02-12-2023}
 */

@Service
public interface LoginServiceImpl extends LoginService {




}
