package com.kartik.register.service;

/**
 * @author {2095949}
 * @Date {03-12-2023}
 */
public interface UserService {
}
